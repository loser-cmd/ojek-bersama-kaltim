# Ojek Bersama Kalimantan Timur 🚀

Aplikasi ojek roda 2 khusus wilayah Kalimantan Timur.

## Fitur
- OTP Firebase (demo)
- Pembayaran tunai & DANA
- Peta & rute Mapbox
- Backend Node.js di Replit
- Frontend Flutter Android

## Cara Jalankan Backend di Replit
```bash
npm install
npm start
```

## Jalankan Frontend Flutter
```bash
flutter pub get
flutter run
```
