import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import fetch from "node-fetch";

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.json({ status: "Backend Ojek Bersama 🚀" });
});

// OTP dummy (nanti bisa pakai Firebase Auth)
app.post("/otp/send", (req, res) => {
  const { phone } = req.body;
  res.json({ success: true, message: `OTP terkirim ke ${phone}` });
});

// Rute dari Mapbox
app.get("/map/route", async (req, res) => {
  const { start, end } = req.query;
  const MAPBOX_TOKEN = process.env.MAPBOX_TOKEN;
  const url = `https://api.mapbox.com/directions/v5/mapbox/driving/${start};${end}?access_token=${MAPBOX_TOKEN}`;
  const response = await fetch(url);
  const data = await response.json();
  res.json(data);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server jalan di port ${PORT}`));
